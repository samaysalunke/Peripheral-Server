/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef _DEBUG_H_
#define _DEBUG_H_

#include "stdio.h"
#include "project.h"	
	
extern void print_event(uint32 event);	
	
	
#endif	

/* [] END OF FILE */