/*
In this example the PEripheral - Server sends notification to the Central for every 100 mS by means of a watchDog Timer
*/



#include <project.h>
#include "stdio.h"
#include "stdbool.h"

#include "LED.h"

#define ERR_INVALID_PDU 0x04
#define CCCD_VALID_BIT_MASK 0x03
#define NOTIFY_BIT_MASK 0x01
#define FALSE           0
//uint8 data[3000] = {"Dose""8""popt"}; //Initialisation of data
int data=1;
#define WDT_COUNTER                 (CY_SYS_WDT_COUNTER1)
#define WDT_COUNTER_MASK            (CY_SYS_WDT_COUNTER1_MASK)
#define WDT_INTERRUPT_SOURCE        (CY_SYS_WDT_COUNTER1_INT) 
#define WDT_COUNTER_ENABLE          (1u)
#define WDT_100SEC                    (32767u)

bool notificationsEnabled=false;

uint32 Timer = 0;
void StackEventHandler(uint32 event,void *eventParam);
//Structure containing address of device 
//Array which is used to store the list of devices added.


CYBLE_API_RESULT_T 		apiResult;

uint8 startNotification;

/*******************************************************************************
* Function Name: StackEventHandler
********************************************************************************
* Summary:
*        Call back event function to handle various events from BLE stack
*
* Parameters:
*  event:		event returned
*  eventParam:	link to value of the event parameter returned
*
* Return:
*  void
*
*******************************************************************************/


/*******************************************************************************
* Function Name: SW_Interrupt
********************************************************************************
*
* Summary:
*   Handles the mechanical button press.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/

//CY_ISR(WdtIsrHandler)
//{
//    /* Clear Interrupt */
//    WdtIsr_ClearPending();
//    Timer = 1;
//    
//}


void StackEventHandler(uint32 event,void *eventParam)
{
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;

    switch(event)
	{
        
		case CYBLE_EVT_STACK_ON:
        printf ("Stack is ON\r\n");
            //Starting Advertisement as soon as Stack is ON
                        apiResult = CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
                if (apiResult != CYBLE_ERROR_OK)
                {
                    printf ("Starting  Advertisement\r\n");
                }
            break;
            
        case CYBLE_EVT_TIMEOUT:
         if( CYBLE_GAP_ADV_MODE_TO ==*(uint16*) eventParam)
            {
                printf ("Advertisement TimedOut\r\n");
                apiResult = CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
                if (apiResult != CYBLE_ERROR_OK)
                {
                    printf ("\nRestarting  Advertisement\r\n");
                }
            }
		
		case CYBLE_EVT_GATT_DISCONNECT_IND:
            startNotification = 0;
			/* Red LED Glows when device is disconnected */
            RED_LED_ON ();
            break;
            
        case CYBLE_EVT_GATTS_WRITE_REQ:
            printf ("GATT_WRITE_REQ received\r\n");
        wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
        if(CYBLE_SENDDATA_DATA_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE == wrReqParam->handleValPair.attrHandle)
        {
        /* Only the first and second lowest significant bit can be
        * set when writing on CCCD. If any other bit is set, then
        * send error code */
        if(FALSE == (wrReqParam->handleValPair.value.val[CYBLE_SENDDATA_DATA_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX] & (~CCCD_VALID_BIT_MASK)))
        {
        /* Set flag for application to know status of notifications.
        * Only one byte is read as it contains the set value. */
        startNotification = wrReqParam->handleValPair.value.val[0];
        printf ("%d notification\r\n",startNotification);
        /* Update GATT DB with latest CCCD value */
        CyBle_GattsWriteAttributeValue(&wrReqParam->handleValPair,FALSE, &cyBle_connHandle, CYBLE_GATT_DB_LOCALLY_INITIATED);
        }
        else
        {
            printf ("error GATT_WRITE\r\n");
        /* Send error response for Invalid PDU against Write
        * request */
        CYBLE_GATTS_ERR_PARAM_T err_param;

        err_param.opcode = CYBLE_GATT_WRITE_REQ;
        err_param.attrHandle = wrReqParam->handleValPair.attrHandle;
        err_param.errorCode = ERR_INVALID_PDU;
        /* Send Error Response */
        (void)CyBle_GattsErrorRsp(cyBle_connHandle, &err_param);
        /* Return to main loop */
        return;
        }
    }
        //mady
        /* Send response to the Write request */
        CyBle_GattsWriteRsp(cyBle_connHandle);
        break;

            
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            printf ("Disconnected \r\n");
            
            // Starting Advertisent again when there is disconnection

            break;
            
			
		case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            printf ("\n\r Connection Established \r\n");
            //Blue LED glows when device is connected
          
            BLUE_LED_ON ();
            break;

		
		case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
         // This Event is received when advertisement is started or stopped.
            if (CyBle_GetState() == CYBLE_STATE_ADVERTISING)
            {
                printf("Advertising...\r\n");
                //Green LED Indicates that Advertisement is going on.
                GREEN_LED_ON();
            }
            else
            {
                RED_LED_ON();
                printf ("Advertisement Stopped \r\n");
               
            }
            
		default:
            printf ("Evt : %lx\r\n",event);
			break;
	}
}
// Watchdog Timer's ISR which sets the Timer Flag high every 100 mS
void Timer_Interrupt(void)
{
    if(CySysWdtGetInterruptSource() & WDT_INTERRUPT_SOURCE)
    {
        Timer = 1;
        
        /* Clears interrupt request  */
        CySysWdtClearInterrupt(WDT_INTERRUPT_SOURCE);
    }
}

//Start and Configure the Watchdog Timer
void WDT_Start(void)
{
    /* Unlock the WDT registers for modification */
    CySysWdtUnlock(); 
    /* Setup ISR callback */
    WdtIsr_StartEx(Timer_Interrupt);
    /* Write the mode to generate interrupt on match */
    CySysWdtWriteMode(WDT_COUNTER, CY_SYS_WDT_MODE_INT);
    /* Configure the WDT counter clear on a match setting */
    CySysWdtWriteClearOnMatch(WDT_COUNTER, WDT_COUNTER_ENABLE);
    /* Configure the WDT counter match comparison value */
    CySysWdtWriteMatch(WDT_COUNTER, WDT_100SEC);
    /* Reset WDT counter */
    CySysWdtResetCounters(WDT_COUNTER);
    /* Enable the specified WDT counter */
    CySysWdtEnable(WDT_COUNTER_MASK);
    /* Lock out configuration changes to the Watchdog timer registers */
    CySysWdtLock();    
}

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  System entry and execution point for application
*
* Parameters:  
*  None
*
* Return: 
*  int

********************************************************************************/

int main()
{
  
    /* Initializing all the Flags and Indexes to 0 */
    ALL_LED_OFF ();
  
    
    CyGlobalIntEnable;  /* Comment this line to disable global interrupts. */
    
    /* Start BLE component and register Event handler function */	
    CyBle_Start(StackEventHandler);

    
    /* Start UART Component which is used for receiving inputs and Debugging */
    UART_Start();
    
    //This Flag is set every 100 mS by the Watchdog Timer for sending notifications
    Timer = 0;
    //Start the Watchdog Timer
    WDT_Start();
    
    for(;;)
    {
        //Checks the internal task queue in the BLE Stack
        CyBle_ProcessEvents();
        
            
   
        //Send Notification after every 100 mS  
        
        if(Timer)
        {       
            Timer = 0;
            /* 'notificationHandle' is handle to store notification data parameters */
            CYBLE_GATTS_HANDLE_VALUE_NTF_T notificationHandle;
            /* Check if the notification bit is set or not */
            if(startNotification & NOTIFY_BIT_MASK)
            {
             /* Update Notification handle with new data*/
                 notificationHandle.attrHandle = CYBLE_SENDDATA_DATA_CHAR_HANDLE;
                notificationHandle.value.val = &data;
                notificationHandle.value.len = 1;
                data++; //change in data
            /* Report data to BLE component for sending data by notifications*/
                  apiResult=   CyBle_GattsNotification(cyBle_connHandle, &notificationHandle);
                if (apiResult != CYBLE_ERROR_OK)
                    {
                        printf ("Sending Data/Command failed\r\n");
                    }
                    else
                    {
                        printf ("Command / Data sent\r\n");
                    }
            }
            
        }
    }
}

/* [] END OF FILE */
